--DOCUMENTATIONS-- last edited April 06, 20124. previous version: doc.V.01 | current version: doc.V.02
/* The datasets provided here is available in kaggle, the link is provided in the project named Managing Duplicate Records in ...
The datasets in kaggle is in denormalized flat file. In my previous project, I made it normalize to avoid differenct anomalies. The
ERD in this project was provided.*/

--BASIC INFORMATION OF categories TABLE
SELECT column_name, data_type
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_name = 'categories';

--CHECKING FOR DUPLICATE RECORDS IN categories TABLE
SELECT name, COUNT(*)
FROM categories
GROUP BY name
HAVING COUNT(*) >1;

/*DUPLICATE RECORDS WERE FOUND
IN categories TABLE*/
SELECT *
FROM categories
WHERE name = 'Electronics';

--categories HANDLING DUPLICATE VALUES
/*DELETE ONE OF THE DUPLICATED RECORDS, THEN
UPDATE THE products TABLE AS IT IS RELATED TO IT*/
DELETE
FROM categories 
WHERE category_id = 37;

--UPDATING THE products TABLE
UPDATE products
SET category_id = 13
WHERE category_id = 37;

--categories VALIDATING DUPLICATES
SELECT name, COUNT(*)
FROM categories
GROUP BY name
HAVING COUNT(*) >1;
--categories NO DUPLICATED VALUES FOUND

--BASIC INFORMATION OF products TABLE
SELECT column_name, data_type
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_name = 'products'
ORDER BY ordinal_position;

--CHECKING FOR DUPLICATE RECORDS IN products TABLE
SELECT 
	name,
	price,
	COUNT(*)
FROM products
GROUP BY name,price
HAVING COUNT(*) >1

--CHECKING FOR DUPLICATE RECORDS IN customers TABLE
SELECT 
	first_name, last_name, email, password, city, 
	country, segment, state, street, zip_code
FROM customers
GROUP BY
	first_name, last_name, email, password, city, 
	country, segment, state, street, zip_code
HAVING COUNT(*) >1

WITH duplicate AS( --USE CTE TO DISPLAY DUPLICATE RECORDS --STEP 2
	SELECT * --VIEWING FOR DUPLICATE RECORDS IN customers TABLE--STEP 1
	FROM customers
	WHERE (first_name, last_name, email, password, city, 
			country, segment, state, street, zip_code) IN 
			(
				SELECT 
				first_name, last_name, email, password, city, 
				country, segment, state, street, zip_code
				FROM customers
				GROUP BY
				first_name, last_name, email, password, city, 
				country, segment, state, street, zip_code
				HAVING COUNT(*) >1
			)
	ORDER BY street, segment DESC, customer_id
		)
SELECT --SEPARATE ORIGINAL IDs TO DUPLICATE IDs --STEP 3
	MAX(CASE WHEN row_num % 2 <> 0 THEN customer_id END) AS duplicated_id,
	MAX(CASE WHEN row_num % 2 = 0 THEN customer_id END) AS original_id
FROM (
	SELECT customer_id,
	ROW_NUMBER() OVER() AS row_num
	FROM duplicate
	) AS numbered_data
GROUP BY CEIL(row_num / 2.0)
ORDER BY MIN(row_num);

--DELETE DUPLICATE RECORDS IN customers TABLE
DELETE
FROM customers AS dup_id
USING customers AS dist_id
WHERE dup_id < dist_id
	AND dup_id.first_name = dist_id.first_name 
	AND dup_id.last_name = dist_id.last_name 
	AND dup_id.email = dist_id.email 
	AND dup_id.password = dist_id.password 
	AND dup_id.city = dist_id.city 
	AND dup_id.country = dist_id.country 
	AND dup_id.segment = dist_id.segment 
	AND dup_id.state = dist_id.state 
	AND dup_id.street = dist_id.street 
	AND dup_id.zip_code = dist_id.zip_code
RETURNING dup_id.customer_id AS deleted_customer_id

--UPDATE THE fact_table TABLE AS IT IS RELATED TO customers_table
UPDATE  fact_table
SET customer_id =
	CASE
		WHEN customer_id = 5286 THEN 12024
		WHEN customer_id = 1495 THEN 9619
		WHEN customer_id = 3765 THEN 4243
		WHEN customer_id = 2083 THEN 9358
		WHEN customer_id = 2005 THEN 7674
		WHEN customer_id = 644 THEN 5486
		WHEN customer_id = 1493 THEN 1722
		WHEN customer_id = 3861 THEN 6840
		WHEN customer_id = 344 THEN 1851
		WHEN customer_id = 1954 THEN 5498
		WHEN customer_id = 11557 THEN 11866
		ELSE customer_id
	END;

--UPDATE THE order_locations TABLE AS IT IS RELATED TO customers_table
UPDATE order_locations
SET order_customer_id =
	CASE
		WHEN order_customer_id = 5286 THEN 12024
		WHEN order_customer_id = 1495 THEN 9619
		WHEN order_customer_id = 3765 THEN 4243
		WHEN order_customer_id = 2083 THEN 9358
		WHEN order_customer_id = 2005 THEN 7674
		WHEN order_customer_id = 644 THEN 5486
		WHEN order_customer_id = 1493 THEN 1722
		WHEN order_customer_id = 3861 THEN 6840
		WHEN order_customer_id = 344 THEN 1851
		WHEN order_customer_id = 1954 THEN 5498
		WHEN order_customer_id = 11557 THEN 11866
		ELSE order_customer_id
	END;

-- I MODIFIED THE order_locations TABLE SINCE THERE ARE RECORS THAT HAVE A LATIN1 CHARACTER
SELECT state
FROM order_locations
WHERE --CONVERT_FROM(city::bytea, 'UTF-8') ~ '[\u0080-\u00FF]' OR
	 CONVERT_FROM(state::bytea, 'UTF-8') ~ '[\u0080-\u00FF]'


SELECT CONVERT_FROM(city:: bytea,'LATIN1') AS updated_state
	FROM order_locations
	
CREATE TABLE order_locations AS
(
SELECT DISTINCT order_id AS location_id,
		CONVERT_FROM(order_city:: bytea,'LATIN1') AS city,
		order_country AS country,
		order_region AS region,
		CONVERT_FROM(order_state:: bytea,'LATIN1') AS state,
		order_zip_code AS zip_code,
		order_customer_id AS customer_id
FROM supply_chains		
);

--order_locations_table
--CHECKING DUPLICATE RECORDS IN order_locations TABLE
SELECT city,country,region, state, zip_code, order_customer_id, COUNT(*)
FROM order_locations
GROUP BY city,country,region, state, zip_code,order_customer_id
HAVING COUNT(*) > 1;

--VALIDATING THE COUNT OF DUPLICATE RECORDS
SELECT city,country,region, state, zip_code, order_customer_id, COUNT(*)
FROM order_locations
GROUP BY city,country,region, state, zip_code,order_customer_id
HAVING COUNT(*) > 2;

--order_locations
SELECT * --FINDING DUPLICATES USING SUBQUERY--STEP 1 -- VALIDATING NUMBER OF DUPLICATES
FROM order_locations
WHERE (city, country, region, state, zip_code, order_customer_id) IN (	 
	SELECT city,country,region, state, zip_code, order_customer_id
	FROM order_locations
	GROUP BY city,country,region, state, zip_code,order_customer_id
	HAVING COUNT(*) > 2)
	
--DELETE THE THIRD DUPLICATE RECORDS
DELETE 
FROM order_locations
WHERE location_id = 5189;

--UPDATE fact_table AS IT IS RELATED TO IT
UPDATE fact_table
SET order_item_id = 603500
WHERE order_item_id = 5189;

--UPDATE order_items AS IT IS RELATED TO IT
UPDATE order_items
SET order_item_id = 60350
WHERE order_item_id = 5189;

--order_locations TABLE
WITH duplicates AS( --USE CTE TO DISPLAY DUPLICATE RECORDS --STEP 2
	SELECT * --VIEWING FOR DUPLICATE RECORDS IN order_locations TABLE--STEP 1
	FROM order_locations
	WHERE (city, country, region, state, zip_code, order_customer_id) IN (	
		SELECT 
			city, country, region, state, zip_code,order_customer_id
		FROM order_locations
		GROUP BY
			city, country, region, state, zip_code,order_customer_id
		HAVING COUNT(*) >1)
	ORDER BY city, country, location_id DESC)
--NOTE: ENSURE THAT THE COUNT OF THE DUPLICATE RECORDS IS EXACTLY 2
SELECT --SEPARATE ORIGINAL IDs TO DUPLICATE IDs --STEP 3
	MAX(CASE WHEN row_num % 2 <> 0 THEN location_id END) AS duplicated_id,
	MAX(CASE WHEN row_num % 2 = 0 THEN location_id END) AS original_id
FROM(
	SELECT location_id,
	ROW_NUMBER() OVER() AS row_num
	FROM duplicates
	) AS numbered_data
GROUP BY CEIL(row_num / 2.0)
ORDER BY MIN(row_num);

--DELETE DUPLICATE RECORDS FROM order_locations TABLE
DELETE
FROM order_locations AS dup_id
USING order_locations AS dist_id
WHERE dup_id < dist_id
	AND dup_id.city = dist_id.city
	AND dup_id.country = dist_id.country
	AND dup_id.region = dist_id.region
	AND dup_id.state = dist_id.state
	AND dup_id.zip_code = dist_id.zip_code
	AND dup_id.order_customer_id = dist_id.order_customer_id
RETURNING dup_id.location_id AS deleted_location_id;

--UPDATE fact_table AS IT IS RELATED TO IT
UPDATE fact_table
SET order_item_id = dl.original_id
FROM deleted_location_id AS dl
WHERE fact_table.order_item_id = dl.duplicated_id;

--UPDATE order_items AS IT IS RELATED TO IT
UPDATE order_items
SET order_item_id = dl.original_id
FROM deleted_location_id AS dl
WHERE order_items.order_item_id = dl.duplicated_id;

--CHECKING DUPLICATE RECORDS IN order_items TABLE
SELECT order_date, item_discount_rate, item_qty, profit_per_order,
		status, order_item_cardprod_id, COUNT(*)
FROM order_items
GROUP BY order_date, item_discount_rate, item_qty, profit_per_order,
		status, order_item_cardprod_id
HAVING COUNT(*) >1; -- NO DUPLICATE RECORDS

--CHECKING DUPLICATE RECORDS IN shipments TABLE
SELECT type, days_for_shipping_real, days_for_shipping_sched, shipped_date,
		shipping_mode,delivery_status,late_delivery_risk, COUNT(*)
FROM shipments
GROUP BY type, days_for_shipping_real, days_for_shipping_sched, shipped_date,
		shipping_mode,delivery_status,late_delivery_risk
HAVING COUNT(*) > 1; -- NO DUPLICATE RECORDS

--CHECKING DUPLICATE RECORDS IN departments TABLE
SELECT name, COUNT(*)
FROM departments
GROUP BY name
HAVING COUNT(*) >1; -- NO DUPLICATE RECORDS

--CHECKING DUPLICATE RECORDS IN stores TABLE
SELECT latitude, longitude, market, department_id, COUNT(*)
FROM stores
GROUP BY latitude, longitude, market, department_id
HAVING COUNT(*) > 1; --NO DUPLICATE RECORDS

--CHECKING DUPLCATE RECORDS IN fact_table TABLE
SELECT customer_id, store_id, product_id, order_item_id, shipment_id, COUNT(*)
FROM fact_table
GROUP BY customer_id, store_id, product_id, order_item_id, shipment_id
HAVING COUNT(*) > 1; --NO DUPLICATE RECORDS








